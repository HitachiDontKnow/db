let tanya = true;

while (tanya) {
  // Menangkap pilihan player
  let p = prompt("Pilih : Gajah, Semut, Orang");

  // Menangkap pilihan komputer
  // Membangkitkan bilangan random
  let comp = Math.random();

  if (comp < 0.34) {
    comp = "gajah";
  } else if (comp > 0.34 && comp < 0.67) {
    comp = "orang";
  } else {
    comp = "semut";
  }

  let hasil = "";

  // Menentukan rules
  if (p == comp) {
    hasil = "SERI!";
  } else if (p == "gajah") {
    // if (comp == "orang") {
    //   hasil = "MENANG!";
    // } else {
    //   hasil = "KALAH!";
    // }
    hasil = comp == "orang" ? "MENANG" : "KALAH!";
  } else if (p == "orang") {
    hasil = comp == "semut" ? "MENANG!" : "KALAH!";
  } else if (p == "semut") {
    hasil = comp == "gajah" ? "MENANG!" : "KALAH!";
  } else {
    hasil = "Kamu memasukkan pilihan yang salah!";
  }

  // Tampilkan hasilnya
  alert(
    "Kamu memilih : " +
      p +
      " , dan Komputer memilih : " +
      comp +
      "\nMaka hasilnya : Kamu " +
      hasil
  );

  tanya = confirm("Lagi?");

  alert("Terima kasih sudah bermain.");
}
